const int ledPins[8] = {7, 8, 9, 10, 11, 12, 13, 14};

int selectedLed = 0;
int blinkDelay = 500;
unsigned long lastToggle = 0;
bool ledState = false;

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 8; i++) {
    pinMode(ledPins[i], OUTPUT);
  }
  Serial.println("Digite: <direcao>,<frequencia>");
  Serial.println("Exemplo: 3,300");
}

void loop() {
  // Leitura do comando serial
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() > 0) {
      int commaIndex = input.indexOf(',');
      if (commaIndex > 0) {
        int dir = input.substring(0, commaIndex).toInt();
        int freq = input.substring(commaIndex + 1).toInt();

        if (dir >= 0 && dir < 8) {
          selectedLed = dir;
          blinkDelay = constrain(freq, 50, 2000); // limita valores extremos
          Serial.print("LED ");
          Serial.print(selectedLed);
          Serial.print(" com frequência ");
          Serial.print(blinkDelay);
          Serial.println("ms");
        }
      }
    }
  }

  // Piscar o LED selecionado
  if (millis() - lastToggle >= blinkDelay) {
    ledState = !ledState;
    lastToggle = millis();

    for (int i = 0; i < 8; i++) {
      digitalWrite(ledPins[i], (i == selectedLed && ledState) ? HIGH : LOW);
    }
  }
}
